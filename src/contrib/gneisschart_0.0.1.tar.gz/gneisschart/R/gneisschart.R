#' gneisschart
#'
#' An R package for drawing charts by Quartz's Gneisschart
#'
#' @name gneisschart
#' @docType package
#' @import htmlwidgets
#' @seealso \url{https://github.com/Quartz/Chartbuilder}
NULL